<?php
define('DB_HOST', $_ENV['DB_HOST'] ?? 'sqlxxx.infinityfree.com');
define('DB_NAME', $_ENV['DB_NAME'] ?? 'if0_XXX');
define('DB_USER', $_ENV['DB_USER'] ?? 'if0_XXX');
define('DB_PASS', $_ENV['DB_PASS'] ?? '*****');
define('BASE_URL', 'https://yoursubdomain.infinityfreeapp.com');
session_start();
